//delete selected entry from the beneficiary table
load = () => {
    var index,
        table = document.getElementById('table');
    for (var i = 1; i < table.rows.length; i++) {
        table.rows[i].cells[3].onclick = function () {      //checking for delete button click
            index = this.parentElement.rowIndex;
            var name = table.rows[index].cells[0].innerText;
            console.log(name);
            deleteRow(name);   // declared at line 84
        };
        //checking for edit button click and fetching values in form with button and heading change
        table.rows[i].cells[4].onclick = function () {
            index = this.parentElement.rowIndex;
            var name = table.rows[index].cells[0].innerText;
            var acc = table.rows[index].cells[1].innerText;
            var IFSC = table.rows[index].cells[2].innerText;
            document.getElementById('heading').innerText = 'Change Beneficiary Details';
            document.getElementById('save').style.display = 'block';
            document.getElementById('submit').style.display = 'none';
            document.getElementById('name').value = name;
            document.getElementById('accNumber').value = acc;
            document.getElementById('IFSC').value = IFSC;
        };
    }
}
///adding beneficiary from form to table of beneficiaries
add = () => {
    var name = document.getElementById('name').value;
    var accNumber = document.getElementById('accNumber').value;
    var IFSC = document.getElementById('IFSC').value;
    var beneficiary = { 'bName': name, 'accountNumber': accNumber, 'IFSC': IFSC, 'addedBy': sessionStorage.getItem('byAccount') };
    beneficiary = JSON.stringify(beneficiary);
    var xhttp = new XMLHttpRequest();
    xhttp.open('POST', 'http://localhost:3000/beneficiary', false);   //http request for posting beneficiary details in json
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(beneficiary);
    alert('Beneficiary Added Succesfully');
    document.getElementById('form').resetForm();
    return false;
}
///avoid character in phone number and account number field
avoidChar = (event) => {
    var k = event ? event.which : window.event.keyCode;
    if (!(k >= 48 && k <= 57)) {
        return false;
    }
}
///appending data dynamically into table
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        var users = this.responseText;
        users = JSON.parse(users);
        for (var i = 0; i < users.length; i++) {
            if (users[i].addedBy == sessionStorage.getItem('byAccount')) {
                var tBody = document.getElementById('tBody');
                var row = document.createElement('tr');
                var td1 = document.createElement('td');
                var td1v = document.createTextNode(users[i].bName)
                td1.appendChild(td1v);
                var td2 = document.createElement('td');
                var td2v = document.createTextNode(users[i].accountNumber)
                td2.appendChild(td2v);
                var td3 = document.createElement('td');
                var td3v = document.createTextNode(users[i].IFSC)
                td3.appendChild(td3v);
                var td4 = document.createElement('td');
                var td4b = document.createElement('button');
                var td4v = document.createTextNode('Delete')
                td4b.appendChild(td4v);
                td4b.setAttribute('id', 'buttonDelete')
                td4.appendChild(td4b);
                var td5 = document.createElement('td');
                var td5b = document.createElement('button');
                var td5v = document.createTextNode('Edit')
                td5b.appendChild(td5v);
                td5b.setAttribute('id', 'buttonEdit')
                td5.appendChild(td5b);
                row.appendChild(td1);
                row.appendChild(td2);
                row.appendChild(td3);
                row.appendChild(td4);
                row.appendChild(td5);
                var editRow = { 'name': td1.innerText, 'acc': td2.innerText };
                editRow = JSON.stringify(editRow)
                sessionStorage.setItem('row', editRow);
                tBody.appendChild(row);
            } 
        }
    }
};
xhttp.open('GET', 'http://localhost:3000/beneficiary', false);
xhttp.send();

///delete function called by load function at line 1, executing delete method in database
deleteRow = (v) => {
    var name = v;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var users = this.responseText;
            users = JSON.parse(users);
            for (var i = 0; i < users.length; i++) {
                if (users[i].bName == name) {
                    var xhttp = new XMLHttpRequest();
                    xhttp.open('DELETE', `http://localhost:3000/beneficiary/${users[i].id}`, true);
                    xhttp.send();
                }
            }
        }
    };
    xhttp.open('GET', `http://localhost:3000/beneficiary`, false);
    xhttp.send();
    location.reload();
}
// edit function called by submit button of edit form and performing edit function by using put method
edit = (event) => {
    event.preventDefault();
    var data = JSON.parse(sessionStorage.getItem('row'));
    var currentUser = sessionStorage.getItem('byAccount')
    name = document.getElementById('name').value;
    acc = document.getElementById('accNumber').value;
    IFSC = document.getElementById('IFSC').value;
    var beneficiary = { 'bName': name, 'accountNumber': acc, 'IFSC': IFSC, 'addedBy': currentUser };
    beneficiary = JSON.stringify(beneficiary);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var users = this.responseText;
            users = JSON.parse(users);
            for (var i = 0; i < users.length; i++) {
                if (users[i].bName == data.name && users[i].accountNumber == data.acc && users[i].addedBy == currentUser) {
                    let xhttp = new XMLHttpRequest();
                    xhttp.open('PUT', `http://localhost:3000/beneficiary/${users[i].id}`, true);
                    xhttp.setRequestHeader('Content-type', 'application/json');
                    xhttp.send(beneficiary);
                    location.reload();
                }
            }
        }
    };
    xhttp.open('GET', 'http://localhost:3000/beneficiary', true);
    xhttp.send();
}
