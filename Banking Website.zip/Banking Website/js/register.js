googleTranslateElementInit=()=> {
  new google.translate.TranslateElement({ pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE }, 'google_translate_element');
}//google translate function for translating page

//validation after submitting register form for the login form and storing important values in seesion storage
validateForm=(event)=> {
  event.preventDefault();
  var response = grecaptcha.getResponse();
  if (response == 0) {
    alert('Please enter correct captcha')
   return false;
  }
  var b = Math.random()
  b = b.toString(36)
  b = b.slice(-8);
 var password = b;
 console.log(password);
 sessionStorage.setItem('password',password);
var userName = document.getElementById('uName').value;
  console.log(userName);
  var customerID = document.getElementById('id').value;
  var userID = `${document.getElementById('uName').value}${document.getElementById('id').value}`
 sessionStorage.setItem('name' , userID);
  var mobile = document.getElementById('mobile').value;
  // var accountNumber = document.getElementById('accountNumber').value;
  var user = { name: userName, 'customerID': customerID, 'IFSC':'OOO123' , 'balance':'1000' ,'userID':userID , 'mobile': mobile, 'accountNumber': mobile , 'password':password};
  var userObj = JSON.stringify(user);
  if (userName == '' || customerID == '' || mobile == '' || userID == '') {
    alert('Enter your Information');
    return false; 
  }
  var xhttp = new XMLHttpRequest();
  xhttp.open('POST', 'http://localhost:3000/users', false);
  xhttp.setRequestHeader('Content-type', 'application/json');
  xhttp.send(userObj);
  window.open('password.html', 'password', 'width=1000px,height=1000px,left=5,top=3'); //opening new window to show username and password 
  window.location.replace('login.html');
  
}

//checking for if the userId already exist or not in the data
check=()=>{
  var customerID = document.getElementById('id').value;  
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var users = this.responseText; 
      users = JSON.parse(users);
      for(var i=0;i<users.length;i++){
        if(customerID == users[i].customerID){
         alert('Online Banking account exist for this user');
        }
      }
    }
  };
  xhttp.open('GET', 'http://localhost:3000/users', true);
  xhttp.send();
}

// function to avoid space in the name and customer id
AvoidSpace=(event)=> {
  var k = event ? event.which : window.event.keyCode;
  if (k == 32) return false;
}

//function to avoid characters on number field 
avoidChar=(event)=> {
  var k = event ? event.which : window.event.keyCode;
  if (!(k>=48 && k<=57) ) {
    return false;
  }
}
